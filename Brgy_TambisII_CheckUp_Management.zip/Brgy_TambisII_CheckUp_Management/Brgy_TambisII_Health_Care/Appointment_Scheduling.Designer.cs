﻿namespace Brgy_TambisII_Health_Care
{
    partial class Appointment_Scheduling
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblResidentID = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tbFName = new System.Windows.Forms.TextBox();
            this.tbLName = new System.Windows.Forms.TextBox();
            this.tbMName = new System.Windows.Forms.TextBox();
            this.dtpBirth = new System.Windows.Forms.DateTimePicker();
            this.tbAge = new System.Windows.Forms.TextBox();
            this.cbStatus = new System.Windows.Forms.ComboBox();
            this.tbContact = new System.Windows.Forms.TextBox();
            this.tbEAdd = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dashBoardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cbGender = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Tahoma", 26.25F);
            this.label1.Location = new System.Drawing.Point(106, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1000, 64);
            this.label1.TabIndex = 0;
            this.label1.Text = "Information And Appointment Scheduling";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.label2.Location = new System.Drawing.Point(525, 172);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(166, 35);
            this.label2.TabIndex = 1;
            this.label2.Text = "ResidentID:";
            // 
            // lblResidentID
            // 
            this.lblResidentID.AutoSize = true;
            this.lblResidentID.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblResidentID.Font = new System.Drawing.Font("Tahoma", 14F);
            this.lblResidentID.Location = new System.Drawing.Point(722, 172);
            this.lblResidentID.Name = "lblResidentID";
            this.lblResidentID.Size = new System.Drawing.Size(30, 34);
            this.lblResidentID.TabIndex = 2;
            this.lblResidentID.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.label4.Location = new System.Drawing.Point(525, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(152, 35);
            this.label4.TabIndex = 3;
            this.label4.Text = "First Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.label5.Location = new System.Drawing.Point(525, 368);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 35);
            this.label5.TabIndex = 4;
            this.label5.Text = "Gender";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.label6.Location = new System.Drawing.Point(525, 414);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(178, 35);
            this.label6.TabIndex = 5;
            this.label6.Text = "Date of Birth";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.label7.Location = new System.Drawing.Point(525, 502);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 35);
            this.label7.TabIndex = 6;
            this.label7.Text = "Status";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label8.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.label8.Location = new System.Drawing.Point(525, 460);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 35);
            this.label8.TabIndex = 7;
            this.label8.Text = "Age";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.label9.Location = new System.Drawing.Point(525, 592);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(142, 35);
            this.label9.TabIndex = 8;
            this.label9.Text = "Email Add";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label10.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.label10.Location = new System.Drawing.Point(525, 546);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(165, 35);
            this.label10.TabIndex = 9;
            this.label10.Text = "Contact No.";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label12.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.label12.Location = new System.Drawing.Point(525, 262);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(180, 35);
            this.label12.TabIndex = 11;
            this.label12.Text = "Middle Name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label13.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.label13.Location = new System.Drawing.Point(525, 312);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(149, 35);
            this.label13.TabIndex = 12;
            this.label13.Text = "Last Name";
            // 
            // tbFName
            // 
            this.tbFName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tbFName.Location = new System.Drawing.Point(711, 222);
            this.tbFName.Name = "tbFName";
            this.tbFName.Size = new System.Drawing.Size(186, 31);
            this.tbFName.TabIndex = 13;
            // 
            // tbLName
            // 
            this.tbLName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tbLName.Location = new System.Drawing.Point(711, 312);
            this.tbLName.Name = "tbLName";
            this.tbLName.Size = new System.Drawing.Size(186, 31);
            this.tbLName.TabIndex = 14;
            // 
            // tbMName
            // 
            this.tbMName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tbMName.Location = new System.Drawing.Point(711, 268);
            this.tbMName.Name = "tbMName";
            this.tbMName.Size = new System.Drawing.Size(186, 31);
            this.tbMName.TabIndex = 14;
            // 
            // dtpBirth
            // 
            this.dtpBirth.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtpBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpBirth.Location = new System.Drawing.Point(711, 418);
            this.dtpBirth.Name = "dtpBirth";
            this.dtpBirth.Size = new System.Drawing.Size(186, 31);
            this.dtpBirth.TabIndex = 16;
            // 
            // tbAge
            // 
            this.tbAge.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tbAge.Location = new System.Drawing.Point(711, 465);
            this.tbAge.Name = "tbAge";
            this.tbAge.Size = new System.Drawing.Size(186, 31);
            this.tbAge.TabIndex = 17;
            this.tbAge.TextChanged += new System.EventHandler(this.tbAge_TextChanged);
            this.tbAge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbAge_KeyPress);
            // 
            // cbStatus
            // 
            this.cbStatus.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cbStatus.FormattingEnabled = true;
            this.cbStatus.Items.AddRange(new object[] {
            "Single ",
            "Married",
            "Annulled",
            "Widowed"});
            this.cbStatus.Location = new System.Drawing.Point(711, 505);
            this.cbStatus.Name = "cbStatus";
            this.cbStatus.Size = new System.Drawing.Size(186, 33);
            this.cbStatus.TabIndex = 18;
            // 
            // tbContact
            // 
            this.tbContact.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tbContact.Location = new System.Drawing.Point(711, 551);
            this.tbContact.Name = "tbContact";
            this.tbContact.Size = new System.Drawing.Size(186, 31);
            this.tbContact.TabIndex = 19;
            this.tbContact.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbContact_KeyPress);
            // 
            // tbEAdd
            // 
            this.tbEAdd.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tbEAdd.Location = new System.Drawing.Point(711, 595);
            this.tbEAdd.Name = "tbEAdd";
            this.tbEAdd.Size = new System.Drawing.Size(186, 31);
            this.tbEAdd.TabIndex = 20;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Brgy_TambisII_Health_Care.Properties.Resources.diagnoses1;
            this.pictureBox1.Location = new System.Drawing.Point(160, 188);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(260, 262);
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(206, 480);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(168, 58);
            this.btnSave.TabIndex = 23;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dashBoardToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1173, 33);
            this.menuStrip1.TabIndex = 24;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // dashBoardToolStripMenuItem
            // 
            this.dashBoardToolStripMenuItem.BackColor = System.Drawing.Color.Teal;
            this.dashBoardToolStripMenuItem.ForeColor = System.Drawing.Color.SandyBrown;
            this.dashBoardToolStripMenuItem.Name = "dashBoardToolStripMenuItem";
            this.dashBoardToolStripMenuItem.Size = new System.Drawing.Size(115, 29);
            this.dashBoardToolStripMenuItem.Text = "DashBoard";
            this.dashBoardToolStripMenuItem.Click += new System.EventHandler(this.dashBoardToolStripMenuItem_Click);
            // 
            // cbGender
            // 
            this.cbGender.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cbGender.FormattingEnabled = true;
            this.cbGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cbGender.Location = new System.Drawing.Point(711, 368);
            this.cbGender.Name = "cbGender";
            this.cbGender.Size = new System.Drawing.Size(186, 33);
            this.cbGender.TabIndex = 25;
            // 
            // Appointment_Scheduling
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Brgy_TambisII_Health_Care.Properties.Resources.Appointment;
            this.ClientSize = new System.Drawing.Size(1173, 749);
            this.Controls.Add(this.cbGender);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tbEAdd);
            this.Controls.Add(this.tbContact);
            this.Controls.Add(this.cbStatus);
            this.Controls.Add(this.tbAge);
            this.Controls.Add(this.dtpBirth);
            this.Controls.Add(this.tbMName);
            this.Controls.Add(this.tbLName);
            this.Controls.Add(this.tbFName);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblResidentID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Appointment_Scheduling";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Appointment_Scheduling";
            this.Load += new System.EventHandler(this.Appointment_Scheduling_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblResidentID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbFName;
        private System.Windows.Forms.TextBox tbLName;
        private System.Windows.Forms.TextBox tbMName;
        private System.Windows.Forms.DateTimePicker dtpBirth;
        private System.Windows.Forms.TextBox tbAge;
        private System.Windows.Forms.ComboBox cbStatus;
        private System.Windows.Forms.TextBox tbContact;
        private System.Windows.Forms.TextBox tbEAdd;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dashBoardToolStripMenuItem;
        private System.Windows.Forms.ComboBox cbGender;
    }
}